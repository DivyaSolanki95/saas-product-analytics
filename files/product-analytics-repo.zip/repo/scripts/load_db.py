import sqlite3
import pandas as pd

conn = sqlite3.connect("/home/claude/project/product_analytics.db")

users = pd.read_csv("/home/claude/project/users.csv", parse_dates=["signup_date"])
events = pd.read_csv("/home/claude/project/events.csv", parse_dates=["event_time"])

users.to_sql("users", conn, if_exists="replace", index=False)
events.to_sql("events", conn, if_exists="replace", index=False)

conn.execute("CREATE INDEX idx_events_user ON events(user_id)")
conn.execute("CREATE INDEX idx_events_name ON events(event_name)")
conn.commit()
conn.close()
print("Loaded into product_analytics.db")
