"""
Generates a synthetic but realistic e-commerce app dataset:
- users.csv: signup info (channel, device, country, signup_date)
- events.csv: event log (signup, product_view, add_to_cart, purchase) with timestamps and revenue

The data has intentional, realistic patterns baked in so the analysis has real findings:
- Paid Social has high signups but weak funnel conversion (bad quality traffic)
- Referral has low volume but best conversion and retention
- iOS users convert & retain better than Android
- Retention decays over weeks but has a small "win-back" bump in week 4 for the Referral channel
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(42)

N_USERS = 6000
START_DATE = datetime(2026, 1, 1)
END_DATE = datetime(2026, 3, 31)  # 90-day window

CHANNELS = ["Paid Social", "Paid Search", "Organic", "Referral", "Email"]
CHANNEL_WEIGHTS = [0.32, 0.22, 0.28, 0.08, 0.10]

# Conversion quality differs by channel (this is the "story" the analyst should find)
CHANNEL_FUNNEL_MULT = {
    "Paid Social": 0.70,   # lots of volume, weak intent
    "Paid Search": 1.00,
    "Organic": 1.05,
    "Referral": 1.45,      # small volume, high intent
    "Email": 1.15,
}

DEVICES = ["iOS", "Android"]
DEVICE_WEIGHTS = [0.55, 0.45]
DEVICE_MULT = {"iOS": 1.15, "Android": 0.90}

COUNTRIES = ["India", "USA", "UK", "Germany", "Brazil"]
COUNTRY_WEIGHTS = [0.40, 0.25, 0.12, 0.10, 0.13]

PRODUCT_CATEGORIES = ["Electronics", "Fashion", "Home & Kitchen", "Beauty", "Sports"]
CATEGORY_PRICE = {"Electronics": 4500, "Fashion": 1200, "Home & Kitchen": 1800, "Beauty": 900, "Sports": 1500}

# ---- Generate users ----
signup_days = (END_DATE - START_DATE).days
users = pd.DataFrame({
    "user_id": range(1, N_USERS + 1),
    "channel": np.random.choice(CHANNELS, N_USERS, p=CHANNEL_WEIGHTS),
    "device": np.random.choice(DEVICES, N_USERS, p=DEVICE_WEIGHTS),
    "country": np.random.choice(COUNTRIES, N_USERS, p=COUNTRY_WEIGHTS),
})
# Signups ramp up slightly over time (growth trend) rather than pure random
day_weights = np.linspace(0.6, 1.4, signup_days + 1)
day_weights = day_weights / day_weights.sum()
signup_offsets = np.random.choice(range(signup_days + 1), N_USERS, p=day_weights)
users["signup_date"] = [START_DATE + timedelta(days=int(d)) for d in signup_offsets]

# ---- Generate funnel events per user ----
events = []

for _, u in users.iterrows():
    uid = u.user_id
    base_mult = CHANNEL_FUNNEL_MULT[u.channel] * DEVICE_MULT[u.device]
    signup_time = u.signup_date + timedelta(hours=np.random.randint(0, 23))
    events.append((uid, "signup", signup_time, None, None, 0.0))

    # Step probabilities (base rates x channel/device multiplier, capped at 0.98)
    p_view = min(0.85 * base_mult, 0.98)
    p_cart = min(0.45 * base_mult, 0.95)
    p_purchase = min(0.28 * base_mult, 0.90)

    did_view = np.random.rand() < p_view
    t = signup_time
    if did_view:
        t = t + timedelta(minutes=np.random.randint(2, 240))
        category = np.random.choice(PRODUCT_CATEGORIES)
        events.append((uid, "product_view", t, category, None, 0.0))

        did_cart = np.random.rand() < p_cart
        if did_cart:
            t = t + timedelta(minutes=np.random.randint(1, 180))
            events.append((uid, "add_to_cart", t, category, None, 0.0))

            did_purchase = np.random.rand() < p_purchase
            if did_purchase:
                t = t + timedelta(minutes=np.random.randint(1, 600))
                price = CATEGORY_PRICE[category] * np.random.uniform(0.8, 1.3)
                events.append((uid, "purchase", t, category, round(price, 2), round(price, 2)))

    # ---- Retention: return visits (open_app events) in following weeks ----
    # Base weekly retention decays; Referral channel gets a small week-4 win-back bump
    weekly_retention_base = [0.38, 0.24, 0.16, 0.11]  # week1..week4 baseline probabilities
    for week_idx, base_p in enumerate(weekly_retention_base, start=1):
        p_return = min(base_p * base_mult, 0.95)
        if u.channel == "Referral" and week_idx == 4:
            p_return = min(p_return * 1.6, 0.95)  # win-back bump
        if np.random.rand() < p_return:
            return_time = signup_time + timedelta(days=7 * week_idx, hours=np.random.randint(0, 23))
            if return_time <= END_DATE:
                events.append((uid, "open_app", return_time, None, None, 0.0))
                # Some returning users purchase again
                if np.random.rand() < min(0.18 * base_mult, 0.5):
                    category = np.random.choice(PRODUCT_CATEGORIES)
                    price = CATEGORY_PRICE[category] * np.random.uniform(0.8, 1.3)
                    events.append((uid, "purchase", return_time + timedelta(minutes=15), category, round(price, 2), round(price, 2)))

events_df = pd.DataFrame(events, columns=["user_id", "event_name", "event_time", "product_category", "price", "revenue"])
events_df = events_df.sort_values(["user_id", "event_time"]).reset_index(drop=True)

users.to_csv("/home/claude/project/users.csv", index=False)
events_df.to_csv("/home/claude/project/events.csv", index=False)

print("Users:", len(users))
print("Events:", len(events_df))
print(events_df.event_name.value_counts())
