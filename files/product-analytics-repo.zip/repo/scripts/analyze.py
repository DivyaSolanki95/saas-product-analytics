import sqlite3
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

conn = sqlite3.connect("/home/claude/project/product_analytics.db")

def q(sql):
    return pd.read_sql_query(sql, conn)

# Split queries.sql into individual statements
with open("/home/claude/project/queries.sql") as f:
    content = f.read()
blocks = [b.strip() for b in content.split(";\n\n\n") if b.strip()]

overall_funnel = q("""
WITH funnel AS (SELECT COUNT(DISTINCT user_id) AS total_signups FROM events WHERE event_name='signup'),
viewed AS (SELECT COUNT(DISTINCT user_id) AS n FROM events WHERE event_name='product_view'),
carted AS (SELECT COUNT(DISTINCT user_id) AS n FROM events WHERE event_name='add_to_cart'),
purchased AS (SELECT COUNT(DISTINCT user_id) AS n FROM events WHERE event_name='purchase')
SELECT f.total_signups, v.n AS viewed_product, c.n AS added_to_cart, p.n AS purchased,
ROUND(100.0*v.n/f.total_signups,1) AS signup_to_view_pct,
ROUND(100.0*c.n/v.n,1) AS view_to_cart_pct,
ROUND(100.0*p.n/c.n,1) AS cart_to_purchase_pct,
ROUND(100.0*p.n/f.total_signups,1) AS overall_conversion_pct
FROM funnel f, viewed v, carted c, purchased p
""")

channel_funnel = q("""
SELECT u.channel,
COUNT(DISTINCT u.user_id) AS signups,
COUNT(DISTINCT CASE WHEN e.event_name='product_view' THEN e.user_id END) AS viewed,
COUNT(DISTINCT CASE WHEN e.event_name='add_to_cart' THEN e.user_id END) AS carted,
COUNT(DISTINCT CASE WHEN e.event_name='purchase' THEN e.user_id END) AS purchased,
ROUND(100.0*COUNT(DISTINCT CASE WHEN e.event_name='purchase' THEN e.user_id END)/COUNT(DISTINCT u.user_id),1) AS signup_to_purchase_pct
FROM users u LEFT JOIN events e ON u.user_id=e.user_id
GROUP BY u.channel ORDER BY signup_to_purchase_pct DESC
""")

device_funnel = q("""
SELECT u.device, COUNT(DISTINCT u.user_id) AS signups,
COUNT(DISTINCT CASE WHEN e.event_name='purchase' THEN e.user_id END) AS purchased,
ROUND(100.0*COUNT(DISTINCT CASE WHEN e.event_name='purchase' THEN e.user_id END)/COUNT(DISTINCT u.user_id),1) AS conversion_pct
FROM users u LEFT JOIN events e ON u.user_id=e.user_id
GROUP BY u.device ORDER BY conversion_pct DESC
""")

cohort_retention = q("""
WITH cohorts AS (SELECT user_id, DATE(signup_date,'weekday 0','-6 days') AS cohort_week FROM users),
returns AS (
  SELECT c.cohort_week, c.user_id,
  CAST((JULIANDAY(e.event_time)-JULIANDAY(u.signup_date))/7 AS INT)+1 AS week_number
  FROM events e JOIN users u ON u.user_id=e.user_id JOIN cohorts c ON c.user_id=e.user_id
  WHERE e.event_name IN ('open_app','purchase') AND JULIANDAY(e.event_time)>JULIANDAY(u.signup_date)
)
SELECT c.cohort_week, COUNT(DISTINCT c.user_id) AS cohort_size,
ROUND(100.0*COUNT(DISTINCT CASE WHEN r.week_number=1 THEN r.user_id END)/COUNT(DISTINCT c.user_id),1) AS week1_retention_pct,
ROUND(100.0*COUNT(DISTINCT CASE WHEN r.week_number=2 THEN r.user_id END)/COUNT(DISTINCT c.user_id),1) AS week2_retention_pct,
ROUND(100.0*COUNT(DISTINCT CASE WHEN r.week_number=3 THEN r.user_id END)/COUNT(DISTINCT c.user_id),1) AS week3_retention_pct,
ROUND(100.0*COUNT(DISTINCT CASE WHEN r.week_number=4 THEN r.user_id END)/COUNT(DISTINCT c.user_id),1) AS week4_retention_pct
FROM cohorts c LEFT JOIN returns r ON r.user_id=c.user_id
GROUP BY c.cohort_week ORDER BY c.cohort_week
""")

channel_retention = q("""
WITH returns AS (
  SELECT u.user_id, u.channel,
  CAST((JULIANDAY(e.event_time)-JULIANDAY(u.signup_date))/7 AS INT)+1 AS week_number
  FROM events e JOIN users u ON u.user_id=e.user_id
  WHERE e.event_name IN ('open_app','purchase') AND JULIANDAY(e.event_time)>JULIANDAY(u.signup_date)
)
SELECT u.channel, COUNT(DISTINCT u.user_id) AS signups,
ROUND(100.0*COUNT(DISTINCT CASE WHEN r.week_number=1 THEN r.user_id END)/COUNT(DISTINCT u.user_id),1) AS week1_pct,
ROUND(100.0*COUNT(DISTINCT CASE WHEN r.week_number=4 THEN r.user_id END)/COUNT(DISTINCT u.user_id),1) AS week4_pct
FROM users u LEFT JOIN returns r ON r.user_id=u.user_id
GROUP BY u.channel ORDER BY week4_pct DESC
""")

revenue_by_channel = q("""
SELECT u.channel, COUNT(e.revenue) AS num_orders, ROUND(SUM(e.revenue),0) AS total_revenue,
ROUND(AVG(e.revenue),0) AS avg_order_value
FROM events e JOIN users u ON u.user_id=e.user_id
WHERE e.event_name='purchase' GROUP BY u.channel ORDER BY total_revenue DESC
""")

category_revenue = q("""
SELECT product_category, COUNT(*) AS num_orders, ROUND(SUM(revenue),0) AS total_revenue
FROM events WHERE event_name='purchase' GROUP BY product_category ORDER BY total_revenue DESC
""")

monthly_signups = q("""
SELECT strftime('%Y-%m', signup_date) AS month, COUNT(*) AS signups
FROM users GROUP BY month ORDER BY month
""")

# Only keep cohorts old enough to have had a full 4-week observation window
DATA_END = pd.Timestamp("2026-03-31")
cohort_retention["cohort_week"] = pd.to_datetime(cohort_retention["cohort_week"])
cohort_retention_full = cohort_retention[cohort_retention["cohort_week"] <= DATA_END - pd.Timedelta(days=28)].copy()

print("=== OVERALL FUNNEL ===\n", overall_funnel, "\n")
print("=== FUNNEL BY CHANNEL ===\n", channel_funnel, "\n")
print("=== FUNNEL BY DEVICE ===\n", device_funnel, "\n")
print("=== COHORT RETENTION ===\n", cohort_retention, "\n")
print("=== RETENTION BY CHANNEL ===\n", channel_retention, "\n")
print("=== REVENUE BY CHANNEL ===\n", revenue_by_channel, "\n")
print("=== CATEGORY REVENUE ===\n", category_revenue, "\n")

# ---------------- CHARTS ----------------
plt.style.use("seaborn-v0_8-whitegrid")
COLORS = ["#2563EB", "#F59E0B", "#10B981", "#EF4444", "#8B5CF6"]

# 1. Overall funnel chart
fig, ax = plt.subplots(figsize=(7, 4.5))
stages = ["Signup", "Product View", "Add to Cart", "Purchase"]
vals = [overall_funnel.total_signups[0], overall_funnel.viewed_product[0],
        overall_funnel.added_to_cart[0], overall_funnel.purchased[0]]
bars = ax.barh(stages[::-1], vals[::-1], color=COLORS[0])
for bar, v in zip(bars, vals[::-1]):
    ax.text(v + 60, bar.get_y() + bar.get_height()/2, f"{v:,}", va="center", fontsize=10)
ax.set_title("User Funnel: Signup to Purchase", fontsize=13, fontweight="bold")
ax.set_xlabel("Users")
plt.tight_layout()
plt.savefig("/home/claude/project/chart_funnel.png", dpi=150)
plt.close()

# 2. Funnel conversion by channel
fig, ax = plt.subplots(figsize=(7, 4.5))
cf = channel_funnel.sort_values("signup_to_purchase_pct")
ax.barh(cf.channel, cf.signup_to_purchase_pct, color=COLORS[1])
for i, v in enumerate(cf.signup_to_purchase_pct):
    ax.text(v + 0.3, i, f"{v}%", va="center", fontsize=10)
ax.set_title("Signup → Purchase Conversion by Channel", fontsize=13, fontweight="bold")
ax.set_xlabel("Conversion %")
plt.tight_layout()
plt.savefig("/home/claude/project/chart_channel_conversion.png", dpi=150)
plt.close()

# 3. Retention curve (overall, averaged across cohorts) + by channel
fig, ax = plt.subplots(figsize=(7, 4.5))
weeks = [1, 2, 3, 4]
overall_ret = [cohort_retention_full[f"week{w}_retention_pct"].mean() for w in weeks]
ax.plot(weeks, overall_ret, marker="o", linewidth=2.5, color=COLORS[0], label="All users (avg)")
for i, ch in enumerate(channel_retention.channel):
    row = channel_retention[channel_retention.channel == ch].iloc[0]
    ax.plot([1, 4], [row.week1_pct, row.week4_pct], marker="o", linestyle="--", alpha=0.6,
            color=COLORS[(i+1) % len(COLORS)], label=ch)
ax.set_title("Weekly Retention: Overall vs by Channel", fontsize=13, fontweight="bold")
ax.set_xlabel("Week After Signup")
ax.set_ylabel("Retention %")
ax.set_xticks(weeks)
ax.legend(fontsize=8, loc="upper right")
plt.tight_layout()
plt.savefig("/home/claude/project/chart_retention.png", dpi=150)
plt.close()

# 4. Revenue by channel
fig, ax = plt.subplots(figsize=(7, 4.5))
rc = revenue_by_channel.sort_values("total_revenue")
ax.barh(rc.channel, rc.total_revenue, color=COLORS[2])
for i, v in enumerate(rc.total_revenue):
    ax.text(v + 2000, i, f"Rs {v:,.0f}", va="center", fontsize=9)
ax.set_title("Total Revenue by Acquisition Channel", fontsize=13, fontweight="bold")
ax.set_xlabel("Revenue (Rs )")
plt.tight_layout()
plt.savefig("/home/claude/project/chart_revenue_channel.png", dpi=150)
plt.close()

# 5. Category revenue
fig, ax = plt.subplots(figsize=(7, 4.5))
cat = category_revenue.sort_values("total_revenue")
ax.barh(cat.product_category, cat.total_revenue, color=COLORS[3])
for i, v in enumerate(cat.total_revenue):
    ax.text(v + 2000, i, f"Rs {v:,.0f}", va="center", fontsize=9)
ax.set_title("Revenue by Product Category", fontsize=13, fontweight="bold")
ax.set_xlabel("Revenue (Rs )")
plt.tight_layout()
plt.savefig("/home/claude/project/chart_category_revenue.png", dpi=150)
plt.close()

# 6. Monthly signup trend
fig, ax = plt.subplots(figsize=(7, 4.5))
ax.plot(monthly_signups.month, monthly_signups.signups, marker="o", linewidth=2.5, color=COLORS[0])
ax.set_title("Monthly Signup Trend", fontsize=13, fontweight="bold")
ax.set_ylabel("Signups")
plt.tight_layout()
plt.savefig("/home/claude/project/chart_signup_trend.png", dpi=150)
plt.close()

# Save all result tables to CSV for reference / appendix
overall_funnel.to_csv("/home/claude/project/results_overall_funnel.csv", index=False)
channel_funnel.to_csv("/home/claude/project/results_channel_funnel.csv", index=False)
device_funnel.to_csv("/home/claude/project/results_device_funnel.csv", index=False)
cohort_retention_full.to_csv("/home/claude/project/results_cohort_retention.csv", index=False)
channel_retention.to_csv("/home/claude/project/results_channel_retention.csv", index=False)
revenue_by_channel.to_csv("/home/claude/project/results_revenue_channel.csv", index=False)
category_revenue.to_csv("/home/claude/project/results_category_revenue.csv", index=False)

print("\nAll charts and result CSVs saved.")
