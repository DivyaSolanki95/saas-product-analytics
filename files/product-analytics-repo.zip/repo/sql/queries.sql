-- =========================================================
-- PRODUCT ANALYTICS SQL QUERIES
-- E-Commerce App: Funnel, Retention & Revenue Analysis
-- =========================================================

-- 1. OVERALL FUNNEL: how many users reach each stage, and conversion rate
--    from the previous stage
WITH funnel AS (
  SELECT
    COUNT(DISTINCT user_id) AS total_signups
  FROM events WHERE event_name = 'signup'
),
viewed AS (
  SELECT COUNT(DISTINCT user_id) AS n FROM events WHERE event_name = 'product_view'
),
carted AS (
  SELECT COUNT(DISTINCT user_id) AS n FROM events WHERE event_name = 'add_to_cart'
),
purchased AS (
  SELECT COUNT(DISTINCT user_id) AS n FROM events WHERE event_name = 'purchase'
)
SELECT
  f.total_signups,
  v.n AS viewed_product,
  c.n AS added_to_cart,
  p.n AS purchased,
  ROUND(100.0 * v.n / f.total_signups, 1) AS signup_to_view_pct,
  ROUND(100.0 * c.n / v.n, 1) AS view_to_cart_pct,
  ROUND(100.0 * p.n / c.n, 1) AS cart_to_purchase_pct,
  ROUND(100.0 * p.n / f.total_signups, 1) AS overall_conversion_pct
FROM funnel f, viewed v, carted c, purchased p;


-- 2. FUNNEL CONVERSION BY ACQUISITION CHANNEL
--    (Reveals which channels bring high-intent vs low-intent traffic)
SELECT
  u.channel,
  COUNT(DISTINCT u.user_id) AS signups,
  COUNT(DISTINCT CASE WHEN e.event_name = 'product_view' THEN e.user_id END) AS viewed,
  COUNT(DISTINCT CASE WHEN e.event_name = 'add_to_cart' THEN e.user_id END) AS carted,
  COUNT(DISTINCT CASE WHEN e.event_name = 'purchase' THEN e.user_id END) AS purchased,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN e.event_name = 'purchase' THEN e.user_id END)
        / COUNT(DISTINCT u.user_id), 1) AS signup_to_purchase_pct
FROM users u
LEFT JOIN events e ON u.user_id = e.user_id
GROUP BY u.channel
ORDER BY signup_to_purchase_pct DESC;


-- 3. FUNNEL CONVERSION BY DEVICE
SELECT
  u.device,
  COUNT(DISTINCT u.user_id) AS signups,
  COUNT(DISTINCT CASE WHEN e.event_name = 'purchase' THEN e.user_id END) AS purchased,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN e.event_name = 'purchase' THEN e.user_id END)
        / COUNT(DISTINCT u.user_id), 1) AS conversion_pct
FROM users u
LEFT JOIN events e ON u.user_id = e.user_id
GROUP BY u.device
ORDER BY conversion_pct DESC;


-- 4. WEEKLY COHORT RETENTION
--    % of each signup-week cohort that returned (open_app or purchase) in weeks 1-4 after signup
WITH cohorts AS (
  SELECT user_id, DATE(signup_date, 'weekday 0', '-6 days') AS cohort_week
  FROM users
),
returns AS (
  SELECT
    c.cohort_week,
    c.user_id,
    CAST((JULIANDAY(e.event_time) - JULIANDAY(u.signup_date)) / 7 AS INT) + 1 AS week_number
  FROM events e
  JOIN users u ON u.user_id = e.user_id
  JOIN cohorts c ON c.user_id = e.user_id
  WHERE e.event_name IN ('open_app', 'purchase')
    AND JULIANDAY(e.event_time) > JULIANDAY(u.signup_date)
)
SELECT
  c.cohort_week,
  COUNT(DISTINCT c.user_id) AS cohort_size,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN r.week_number = 1 THEN r.user_id END) / COUNT(DISTINCT c.user_id), 1) AS week1_retention_pct,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN r.week_number = 2 THEN r.user_id END) / COUNT(DISTINCT c.user_id), 1) AS week2_retention_pct,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN r.week_number = 3 THEN r.user_id END) / COUNT(DISTINCT c.user_id), 1) AS week3_retention_pct,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN r.week_number = 4 THEN r.user_id END) / COUNT(DISTINCT c.user_id), 1) AS week4_retention_pct
FROM cohorts c
LEFT JOIN returns r ON r.user_id = c.user_id
GROUP BY c.cohort_week
ORDER BY c.cohort_week;


-- 5. RETENTION BY CHANNEL (week 1 vs week 4) -- spot the Referral win-back effect
WITH returns AS (
  SELECT
    u.user_id, u.channel,
    CAST((JULIANDAY(e.event_time) - JULIANDAY(u.signup_date)) / 7 AS INT) + 1 AS week_number
  FROM events e
  JOIN users u ON u.user_id = e.user_id
  WHERE e.event_name IN ('open_app', 'purchase')
    AND JULIANDAY(e.event_time) > JULIANDAY(u.signup_date)
)
SELECT
  u.channel,
  COUNT(DISTINCT u.user_id) AS signups,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN r.week_number = 1 THEN r.user_id END) / COUNT(DISTINCT u.user_id), 1) AS week1_pct,
  ROUND(100.0 * COUNT(DISTINCT CASE WHEN r.week_number = 4 THEN r.user_id END) / COUNT(DISTINCT u.user_id), 1) AS week4_pct
FROM users u
LEFT JOIN returns r ON r.user_id = u.user_id
GROUP BY u.channel
ORDER BY week4_pct DESC;


-- 6. REVENUE BY CHANNEL & AVERAGE ORDER VALUE
SELECT
  u.channel,
  COUNT(e.revenue) AS num_orders,
  ROUND(SUM(e.revenue), 0) AS total_revenue,
  ROUND(AVG(e.revenue), 0) AS avg_order_value
FROM events e
JOIN users u ON u.user_id = e.user_id
WHERE e.event_name = 'purchase'
GROUP BY u.channel
ORDER BY total_revenue DESC;


-- 7. TOP PRODUCT CATEGORIES BY REVENUE
SELECT
  product_category,
  COUNT(*) AS num_orders,
  ROUND(SUM(revenue), 0) AS total_revenue
FROM events
WHERE event_name = 'purchase'
GROUP BY product_category
ORDER BY total_revenue DESC;


-- 8. MONTHLY SIGNUP TREND
SELECT
  strftime('%Y-%m', signup_date) AS month,
  COUNT(*) AS signups
FROM users
GROUP BY month
ORDER BY month;
